@echo off
net session >nul 2>&1
if %errorLevel% neq 0 (powershell -Command "Start-Process '%~f0' -Verb RunAs" & exit /b)
echo Stopping and removing CCTV-Dashboard service...
nssm stop CCTV-Dashboard
nssm remove CCTV-Dashboard confirm
echo Done. Service removed.
pause
