@echo off
title CCTV Dashboard — Service Installer
color 0A

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Requesting Administrator...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"

echo ============================================
echo   CCTV Dashboard — Background Service
echo   No CMD window will appear after install
echo ============================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorLevel% neq 0 (
    echo ERROR: Python not found! Install from python.org
    pause & exit /b
)

:: Install requirements silently
echo [1/4] Installing Python packages...
pip install flask requests openpyxl urllib3 pillow opencv-python -q --disable-pip-version-check
echo Done.

:: Install NSSM (Non-Sucking Service Manager)
echo [2/4] Checking NSSM...
where nssm >nul 2>&1
if %errorLevel% neq 0 (
    echo Downloading NSSM...
    powershell -Command "Invoke-WebRequest -Uri 'https://nssm.cc/release/nssm-2.24.zip' -OutFile '%TEMP%\nssm.zip'"
    powershell -Command "Expand-Archive '%TEMP%\nssm.zip' -DestinationPath '%TEMP%\nssm' -Force"
    copy "%TEMP%\nssm\nssm-2.24\win64\nssm.exe" "%SystemRoot%\System32\nssm.exe" >nul
    echo NSSM installed.
) else (
    echo NSSM already installed.
)

:: Remove old service if exists
echo [3/4] Registering Windows Service...
nssm stop CCTV-Dashboard >nul 2>&1
nssm remove CCTV-Dashboard confirm >nul 2>&1

:: Get Python path
for /f "delims=" %%i in ('python -c "import sys; print(sys.executable)"') do set PYTHON_EXE=%%i
set APP_DIR=%~dp0
set APP_FILE=%~dp0app.py

:: Install as Windows Service
nssm install CCTV-Dashboard "%PYTHON_EXE%" "%APP_FILE%"
nssm set CCTV-Dashboard AppDirectory "%APP_DIR%"
nssm set CCTV-Dashboard DisplayName "CCTV Surveillance Dashboard"
nssm set CCTV-Dashboard Description "Aura Jewels CCTV monitoring dashboard - runs at http://localhost:5000"
nssm set CCTV-Dashboard Start SERVICE_AUTO_START
nssm set CCTV-Dashboard AppStdout "%APP_DIR%logs\service_out.log"
nssm set CCTV-Dashboard AppStderr "%APP_DIR%logs\service_err.log"
nssm set CCTV-Dashboard AppRotateFiles 1
nssm set CCTV-Dashboard AppRotateOnline 1
nssm set CCTV-Dashboard AppRotateBytes 1048576

:: Start the service
nssm start CCTV-Dashboard

echo [4/4] Done!
echo.
echo ============================================
echo   Service installed successfully!
echo.
echo   Name    : CCTV-Dashboard
echo   Status  : RUNNING in background
echo   URL     : http://localhost:5000
echo   Login   : Admin / Auracctv#2024
echo.
echo   To manage:
echo     nssm stop CCTV-Dashboard
echo     nssm start CCTV-Dashboard
echo     nssm restart CCTV-Dashboard
echo.
echo   Or: Open Services.msc and find CCTV-Dashboard
echo ============================================
echo.

:: Open browser
start "" http://localhost:5000

pause
