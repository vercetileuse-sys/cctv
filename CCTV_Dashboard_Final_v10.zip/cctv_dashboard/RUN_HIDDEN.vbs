' Run dashboard silently — no CMD window at all
' Double-click this file to start dashboard invisibly
Dim fso, shell, dir
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = dir
shell.Run "python " & Chr(34) & dir & "\app.py" & Chr(34), 0, False
' 0 = hidden window, False = don't wait
MsgBox "CCTV Dashboard started!" & Chr(13) & Chr(10) & "Open: http://localhost:5000" & Chr(13) & Chr(10) & "Login: Admin / Auracctv#2024", 64, "CCTV Dashboard"
